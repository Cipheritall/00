:root {
--primary-color: <?php echo esc_html(get_theme_mod('pr_color', '#36bb91')); ?>;
--primary-links-hover-color: <?php echo esc_html(get_theme_mod('pr_links_h_color', '#36bb91')); ?>;
--primary-bg-color: <?php echo esc_html(get_theme_mod('pr_bg_color', '#1c222b')); ?>;
--header-bg-color: <?php echo esc_html(get_theme_mod('h_bg_color', '#1c222b')); ?>;
--footer-bg-color: <?php echo esc_html(get_theme_mod('f_bg_color', '#f8f8f8')); ?>;
--primary-dark-color: <?php echo esc_html(get_theme_mod('pr_d_color', '#b6bdc5')); ?>;
--title-color: <?php echo esc_html(get_theme_mod('title_color', '#ffffff')); ?>;
--fw-title-color: <?php echo esc_html(get_theme_mod('fw_title_color', '#1a1a1a')); ?>;
--btn-bg-color: <?php echo esc_html(get_theme_mod('btn_bg_color', '#36bb91')); ?>;
--btn-hover-color: <?php echo esc_html(get_theme_mod('btn_h_color', '#1a5e49')); ?>;
--txt-select-bg-color: <?php echo esc_html(get_theme_mod('txt_select_bg_color', '#f3d7f463')); ?>;
--logo-height: <?php echo esc_html(get_theme_mod('logo_height', '40')) . 'px'; ?>;
}