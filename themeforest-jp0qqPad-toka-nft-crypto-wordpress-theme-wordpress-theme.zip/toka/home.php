<?php
/**
 * Template for Blog Posts Index page and Site Front Page
 */
get_template_part('page-templates/template-blog-col-1-sidebar');